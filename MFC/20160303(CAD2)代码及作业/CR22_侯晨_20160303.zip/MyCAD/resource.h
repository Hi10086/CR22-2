//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CAD.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CADTYPE                     129
#define IDD_DIALOG1                     130
#define IDR_MENU1                       131
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_RADIO3                      1002
#define IDC_RADIO4                      1003
#define IDC_EDIT_WIDTH                  1004
#define IDC_SPIN1                       1006
#define IDC_BTN_COLOR                   1008
#define IDC_EDIT_PEN_COLOR              1009
#define IDM_LINE                        32771
#define IDM_RECT                        32772
#define IDM_SETTING                     32773
#define IDM_SELECT                      32774
#define IDM_EDIT                        32775
#define ID_MENUITEM32776                32776
#define ID_MENU_MOVE                    32776
#define ID_MENUITEM32777                32777
#define ID_MENUITEM32778                32778
#define ID_MENU_DELITE                  32778
#define ID_MENUITEM32779                32779
#define ID_MENU_COPY                    32779
#define ID_MENUITEM32780                32780
#define ID_MENU_PASTE                   32780
#define ID_MENUITEM32781                32781
#define ID_MENU_UNDO1                   32781
#define ID_MENUITEM32782                32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
