//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SankTools.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SANKTOOLS_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDR_MENU_PROCESS                130
#define IDD_MODULE_DLG                  131
#define IDD_PRO_DLG                     132
#define IDD_INJECT_DIALOG               133
#define IDD_THREAD_DLG                  134
#define IDC_TAB                         1000
#define IDC_LIST1                       1001
#define IDC_EDIT_DLL_PATH               1002
#define IDC_DLL_SEL                     1004
#define IDC_EDIT_MAP_VALUE              1005
#define IDC_BUTTON_INJECT               1006
#define IDC_BUTTON_END                  1007
#define IDC_CHECK_MEM_MAP               1008
#define IDC_EDIT_MAP_VALUE_RETURN       1009
#define IDC_EDIT_MAPOBJ_NAME            1010
#define ID_MENU_PRO_FLUSH               32771
#define ID_MENU_PRO_MODULE              32772
#define ID_MENU_MODULE_FLUSH            32773
#define ID_MENU_MODULE_INGECT           32774
#define ID_MENU_PRO_INJECT              32775
#define ID_MENU_PRO_THREAD              32776
#define ID_MENU_THREAD_MSG              32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
