// IShapeFactory.cpp: implementation of the IShapeFactory class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SankCAD.h"
#include "IShapeFactory.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IShapeFactory::IShapeFactory()
{

}

IShapeFactory::~IShapeFactory()
{

}
